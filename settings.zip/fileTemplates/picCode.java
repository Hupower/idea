
import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
@javax.servlet.annotation.WebServlet(name = "${Entity_Name}",urlPatterns = "/ ")
public class ${Class_Name} extends javax.servlet.http.HttpServlet {
     
     private Random random = new Random();

    //随机的到一种颜色
    private Color getRandomColor() {
        //计算机三种基色，每种颜色取值0-255之间，分别是红r，绿g，蓝b
        int r = random.nextInt(256);
        int g = random.nextInt(256);
        int b = random.nextInt(256);
        return new Color(r, g, b);
    }
     
     @Override
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {
    
     //创建图片，绘制白色的矩形，参数1：宽，高，矩形模式
        int width = 90, height = 30;
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_3BYTE_BGR);
        //得到画笔对象
        Graphics graphics = img.getGraphics();
        graphics.setColor(Color.white);
        //画矩形
        graphics.fillRect(0, 0, width, height);

        //在白色的矩形上绘制4个验证码
        char[] arr = {'A', 'B', 'C', 'D', 'N', 'E', 'W', 'b', 'o', 'y', '1', '2', '3', '4', '5', '6', '7', '8'};
        //设置字体
        graphics.setFont(new Font(Font.SANS_SERIF, Font.BOLD + Font.ITALIC, 19));
        //随机取4个
        for (int i = 0; i < 4; i++) {
            //得到数组索引
            int index = random.nextInt(arr.length);
            char c = arr[index];
            //设置颜色
            graphics.setColor(getRandomColor());
            //画字符串，参数:字符串，x，y位置
            int x = 10 + (i * 20);
            int y = 20;
            graphics.drawString(String.valueOf(c), x, y);
        }
        //在验证码上绘制8条随机线
        for (int i = 0; i < 8; i++) {
            graphics.setColor(getRandomColor());
            int x1 = random.nextInt(width);
            int x2 = random.nextInt(width);
            int y1 = random.nextInt(height);
            int y2 = random.nextInt(height);
            graphics.drawLine(x1, x2, y1, y2);
        }
        //输出到浏览器,参数：要输出图片，图片格式，响应输出流
        ImageIO.write(img, "jpeg", response.getOutputStream());
    }
    
     @Override
    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, java.io.IOException {
     this.doPost(request,response);
    }
}
