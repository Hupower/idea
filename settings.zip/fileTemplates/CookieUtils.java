import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

/**
 * Cookie的工具类
 */
public class CookieUtils {
    /**
     * 通过Cookie的名字得到它的值
     *
     * @param request 请求对象
     * @param name    要找的键
     * @return 找到的值，如果没有找到返回null
     */
    public static String getCookieValue(HttpServletRequest request, String name) {
        //得到浏览器发送回来的所有Cookie
        Cookie[] cookies = request.getCookies();

        //判断Cookie数组是否为空
        if (cookies != null) {
            //不为空遍历，查找每一个键是否等于name，如果相等，返回它的值
            for (Cookie cookie : cookies) {
                if (cookie.getName().equals(name)) {
                    return cookie.getValue();
                }
            }
        }
        //没有找到，就返回null
        return null;
    }
}